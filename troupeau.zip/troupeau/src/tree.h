

void Affichertroupeaux(GtkWidget* treeview1,char*l);
int Cherchertroupeaux(GtkWidget* treeview1,char*l,char*id);
