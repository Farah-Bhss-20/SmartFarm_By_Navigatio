#include <gtk/gtk.h>
void ajouter_troupeaux(troupeaux t );

int exist_troupeaux(char*id);
void supprimer_troupeaux(char*id);
int Somme (char type[]) ;
