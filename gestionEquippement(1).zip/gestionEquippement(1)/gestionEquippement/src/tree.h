

void Afficherequipement(GtkWidget* liste);
int Chercherequipement(GtkWidget* liste,char*l,char*nm);
