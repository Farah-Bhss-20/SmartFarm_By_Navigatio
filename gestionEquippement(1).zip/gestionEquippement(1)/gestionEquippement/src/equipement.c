#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "callbacks.h"
#include<string.h>
#include "equipement.h"

//Ajouter un equipement 

void ajouter_equipement( equipement e){
FILE*f=NULL; //flot de donnée
f=fopen("equipement.txt","a+");
fprintf(f,"%s %s %s %s %d %d %d %s \n",e.nom,e.marque,e.reference,e.type,e.ddf.j,e.ddf.m,e.ddf.a,e.etat);;  
fclose(f); 
}
//********************************************************





//verifier l'existance 

int exist_equipement(char*reference){
FILE*f=NULL;
 equipement e;
f=fopen("equipement.txt","r");// ouverture du fichier equipement en  mode lecture 
while(fscanf(f,"%s %s %s %s %d %d %d %s\n",e.nom,e.marque,e.reference,e.type,&e.ddf.j,&e.ddf.m,&e.ddf.a,e.etat)!=EOF){
if(strcmp(e.reference,reference)==0)
return 1;   //id existe deja 
}
fclose(f);
return 0;
}

//*****************************************************************




//supprimer equi 
void supprimer_equipement(char*reference){
FILE*f=NULL;
FILE*f1=NULL;
equipement e ;
f=fopen("equipement.txt","r");
f1=fopen("ancien.txt","w+");//mode lecture et ecriture 
while(fscanf(f,"%s %s %s %s %d %d %d %s\n",e.nom,e.marque,e.reference,e.type,&e.ddf.j,&e.ddf.m,&e.ddf.a,e.etat)!=EOF){
if(strcmp(reference,e.reference)!=0)fprintf(f1,"%s %s %s %s %d %d %d %s \n",e.nom,e.marque,e.reference,e.type,e.ddf.j,e.ddf.m,e.ddf.a,e.etat);
}
fclose(f);
fclose(f1);
remove("equipement.txt");
rename("ancien.txt","equipement.txt");
}

//******************************************************************



void modifier_equipement(equipement e){
FILE*f=NULL;
FILE*f1=NULL;
equipement eq ;
f=fopen("equipement.txt","r");
f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %s %d %d %d %s\n",eq.nom,eq.marque,eq.reference,eq.type,&eq.ddf.j,&eq.ddf.m,&eq.ddf.a,eq.etat)!=EOF){
if( strcmp(e.reference,eq.reference)==0)
{
fprintf(f1,"%s %s %s %s %d %d %d %s \n",e.nom,e.marque,e.reference,e.type,e.ddf.j,e.ddf.m,e.ddf.a,e.etat);
}
else
{
fprintf(f1,"%s %s %s %s %d %d %d %s \n",eq.nom,eq.marque,eq.reference,eq.type,eq.ddf.j,eq.ddf.m,eq.ddf.a,eq.etat);
}

}
fclose(f);
fclose(f1);
remove("equipement.txt");
rename("ancien.txt","equipement.txt");
}

/////////******/////////////////
int exist_annee(tabAnneeMoy*e,int n,int aa){
int i=0;
for(i=0;i<n;i++){
    if(e[i].aa==aa)return 1;
}
return 0;
}
int remplir_annees(tabAnneeMoy*e,char*fich){
FILE*f=NULL;
int i=-1;
arrosage t;
f=fopen(fich,"r");
while(fscanf(f,"%s %d %d %d %f\n",t.idArrosage,&t.jj,&t.mm,&t.aa,&t.valeur)!=EOF){
if(exist_annee(e,i+1,t.aa)==0){
i++;
e[i].aa=t.aa;

}
}
fclose(f);
return i+1;
}
int maximum(tabAnneeMoy*e,int n){
int i,max_annee = e[0].aa;
float max_val=e[0].somme;
for (i=1;i<n;i++){
if(e[i].somme >max_val){
    max_val = e[i].somme ;
    max_annee = e[i].aa;
}

}
return max_annee;

}


float calculer_somme(int aa, char*fich){
float s=0;
arrosage t;
FILE*f=NULL;
f=fopen(fich,"r");
while(fscanf(f,"%s %d %d %d %f\n",t.idArrosage,&t.jj,&t.mm,&t.aa,&t.valeur)!=EOF){
        if(t.aa==aa){
            s+=t.valeur;
            
        }
}
fclose(f);
return s;
}


int trouver_annee_plus_seche(char*fich){
tabAnneeMoy e[50];
int j,n,annee_max;
n = remplir_annees(e,fich);
for (j=0;j<n;j++){
    e[j].somme = calculer_somme(e[j].aa, fich);
}

annee_max=maximum(e,n);


return annee_max;


}













