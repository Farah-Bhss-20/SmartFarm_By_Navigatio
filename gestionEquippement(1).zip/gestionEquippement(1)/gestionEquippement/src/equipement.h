#include <gtk/gtk.h>
typedef struct tabAnneeMoy tabAnneeMoy;
struct tabAnneeMoy{
int aa;
float somme;
};
void ajouter_equipement(equipement e );

int exist_equipement(char*reference);
void supprimer_equipement(char*reference);
void modifier_equipement(equipement e);
 ////*********///
int exist_annee(tabAnneeMoy*e,int n,int aa);
int remplir_annees(tabAnneeMoy*e,char*fich);
int maximum(tabAnneeMoy*e,int n);
float calculer_somme(int aa, char*fich);
int trouver_annee_plus_seche(char*fich);

