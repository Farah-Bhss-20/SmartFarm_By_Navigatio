#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include <gtk/gtk.h>
#include "interface.h"
#include "callbacks.h"
#include "tree.h"

enum
{
      ENOM,
      EMARQUE,
      EREFERENCE,
      ETYPE,
	J,
	M,
	A,
	EETAT,
      COLUMNS,
};

GtkListStore *adstore;/*creation du modele de type liste*/
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/
FILE *f;

void Afficherequipement(GtkWidget* liste)
{

GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    equipement e;
            char nom[20];
	    char marque[20];
	    char reference[20];
	    char type[20];
	    int j;
	    int m;
	    int a;
	    char etat[20];
	
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("nom",renderer ,"text",ENOM, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("marque",renderer ,"text",EMARQUE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("reference",renderer ,"text",EREFERENCE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("type",renderer ,"text",ETYPE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	   
	
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("j",renderer ,"text",J, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("m",renderer ,"text",M, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("a",renderer ,"text",A, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("etat",renderer ,"text",EETAT, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    }
	    store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,  G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);

	    f=fopen("equipement.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("equipement.txt","a+");
			while(fscanf(f,"%s %s %s %s %d %d %d %s \n",nom,marque,reference,type,&j,&m,&a,etat)!=EOF)
			{
				gtk_list_store_append (store, &iter);
				gtk_list_store_set (store, &iter, ENOM, nom, EMARQUE, marque, EREFERENCE, reference, ETYPE,type,J,j,M,m,A,a,EETAT,etat, -1);
			}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }

}





int Chercherequipement(GtkWidget *liste,char*l,char*nm)
{
GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    equipement e;
            char nom[20];
	    char marque[20];
	    char reference[20];
	    char type[20];
	    int j;
	    int m;
	    int a;
	    char etat[20];
	    int nb=0;
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("nom",renderer ,"text",ENOM, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("marque",renderer ,"text",EMARQUE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("reference",renderer ,"text",EREFERENCE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("type",renderer ,"text",ETYPE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	   
	
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("j",renderer ,"text",J, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("m",renderer ,"text",M, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("a",renderer ,"text",A, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("etat",renderer ,"text",EETAT, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    }
	    store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,  G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);

	    f=fopen(l,"r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen(l,"a+");
			while(fscanf(f,"%s %s %s %s %d %d %d %s \n",nom,marque,reference,type,&j,&m,&a,etat)!=EOF)
			{ if (strcmp(nm,reference)==0){ nb++;
				gtk_list_store_append (store, &iter);
				gtk_list_store_set (store, &iter, ENOM, nom, EMARQUE, marque, EREFERENCE, reference, ETYPE,type,J,j,M,m,A,a,EETAT,etat, -1);
			}}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
return nb;
}



