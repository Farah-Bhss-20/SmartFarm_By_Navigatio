#include <gtk/gtk.h>
GtkWidget *acceuil;
  GtkWidget *gestion;
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *window3;
GtkWidget *window23;

typedef struct{
int j;
int m;
int a;

}date;

typedef struct arrosage arrosage;
struct arrosage{
char idArrosage[30];
int jj;
int mm;
int aa;
float valeur;
};

typedef struct{
char nom[20];
char marque[20];
char reference[20];
char type[20];
date ddf;
char etat[20];
}equipement;


void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_bmodifier_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_bsupprimer_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bafficher12_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Ajouterequipement_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifierequipement_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherequipement_clicked          (GtkButton       *button,
                                        gpointer         user_data);



void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton3occmodif_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_checkbutton2confmodif_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonoccajout_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2neufajou_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbutton1ajou_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1ajout_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3occmodifier_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_eqAfficher_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ouisupp_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_nonsup_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifretour_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeretourr_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
void
on_treeajou_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void
on_modifaffich_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
void
on_buttonradioajou_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
void
on_radiobutton2affich_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);










void
on_annee_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonseche_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonreturnseche_clicked           (GtkButton       *button,
                                        gpointer         user_data);
