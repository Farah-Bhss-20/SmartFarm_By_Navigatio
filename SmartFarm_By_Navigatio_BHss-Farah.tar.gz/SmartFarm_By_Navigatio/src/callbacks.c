#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "functions.h"




void
on_button1_connexion_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
 gtk_widget_hide(window1_acceuil);
    gtk_widget_show(window2_cnx);
}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *label1_meilleur = (GtkWidget *)g_object_get_data(G_OBJECT(window1_acceuil), "label1_meilleur");
    GtkWidget *entry1_annee_meill = (GtkWidget *)g_object_get_data(G_OBJECT(window1_acceuil), "entry1_annee_meill");
    gchar *tx = gtk_entry_get_text(GTK_ENTRY(entry1_annee_meill));

    gchar lb[1000], *cc = verify_assid(tx);
    memset(lb,0,1000);
    strcpy(lb, "Le meilleur est:");
    strcat(lb, cc);
    gtk_label_set_label(GTK_LABEL(label1_meilleur), lb);
}


void
on_button_cal_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button5_seche_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button2_cnx_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id = (GtkWidget *)g_object_get_data(G_OBJECT(window2_cnx), "entry2_id");
    GtkWidget *pwd = (GtkWidget *)g_object_get_data(G_OBJECT(window2_cnx), "entry3_pwd");

    const char *id_text = gtk_entry_get_text(GTK_ENTRY(id));
    const char *pwd_text = gtk_entry_get_text(GTK_ENTRY(pwd));

    if (verify_connection(id_text, pwd_text) == FALSE)
    {
        GtkWidget *dialog;
        dialog = gtk_message_dialog_new(GTK_WINDOW(window2_cnx),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        GTK_MESSAGE_INFO,
                                        GTK_BUTTONS_OK,
                                        "Mot de passe ou identifiant n'est pas correct");
        gtk_window_set_title(GTK_WINDOW(dialog), "Information");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
    else
    {
        gtk_widget_hide(window2_cnx);
        gtk_widget_show(window3_liste);
    }
}


void
on_button3_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show(window1_acceuil);
    gtk_widget_hide(window2_cnx);
}


void
on_button4_rech_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button9_ret_acc_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
    gtk_widget_show(window2_cnx);
    gtk_widget_hide(window3_liste);

}


void
on_button6_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
    window5_fiche_modify = TRUE;
    GtkWidget *entry6_id = g_object_get_data(G_OBJECT(window5_fiche), "entry6_id");
    GtkWidget *entry7_nom = g_object_get_data(G_OBJECT(window5_fiche), "entry7_nom");
    GtkWidget *entry8_prenom = g_object_get_data(G_OBJECT(window5_fiche), "entry8_prenom");
    GtkWidget *entry9_ntel = g_object_get_data(G_OBJECT(window5_fiche), "entry9_ntel");
    GtkWidget *checkbutton3_gt = g_object_get_data(G_OBJECT(window5_fiche), "checkbutton3_gt");
    GtkWidget *checkbutton2_gc = g_object_get_data(G_OBJECT(window5_fiche), "checkbutton2_gc");
    GtkWidget *checkbutton1_gouv = g_object_get_data(G_OBJECT(window5_fiche), "checkbutton1_gouv");
    gtk_entry_set_text(GTK_ENTRY(entry6_id), "");
    gtk_entry_set_text(GTK_ENTRY(entry7_nom), "");
    gtk_entry_set_text(GTK_ENTRY(entry8_prenom), "");
    gtk_entry_set_text(GTK_ENTRY(entry9_ntel), "");
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkbutton3_gt), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkbutton2_gc), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkbutton1_gouv), FALSE);

    GtkTreeView *ouv = (GtkTreeView *)g_object_get_data(G_OBJECT(window3_liste), "treeview1_ouv");
    GtkTreeSelection *tsel = gtk_tree_view_get_selection(ouv);
    GtkTreeIter iter;
    GtkTreeModel *tm;
    GtkTreePath *path;
    if (gtk_tree_selection_get_selected(tsel, &tm, &iter))
    {
        gchar *i, *n, *p, *t, *w;
        gboolean c, r, o;
        gtk_tree_model_get(tm, &iter, 0, &i, 1, &n, 2, &p, 3, &t, 4, &c, 5, &r, 6, &o, 7, &w, -1);
        gtk_entry_set_text(GTK_ENTRY(entry6_id), i);
        gtk_entry_set_text(GTK_ENTRY(entry7_nom), n);
        gtk_entry_set_text(GTK_ENTRY(entry8_prenom), p);
        gtk_entry_set_text(GTK_ENTRY(entry9_ntel), t);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkbutton1_gouv), c);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkbutton2_gc), r);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkbutton3_gt), o);
        gtk_widget_hide(window3_liste);
        gtk_widget_show(window5_fiche);
    }
    else
    {
        GtkWidget *dialog;
        dialog = gtk_message_dialog_new(GTK_WINDOW(window2_cnx),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        GTK_MESSAGE_INFO,
                                        GTK_BUTTONS_OK,
                                        "Selectionner");
        gtk_window_set_title(GTK_WINDOW(dialog), "Information");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }

}


void
on_button7_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkTreeView *ouv = (GtkTreeView *)g_object_get_data(G_OBJECT(window3_liste), "treeview1_ouv");
    GtkTreeSelection *tsel = gtk_tree_view_get_selection(ouv);
    GtkTreeIter iter;
    GtkTreeModel *tm;
    if (gtk_tree_selection_get_selected(tsel, &tm, &iter))
    {
        gchar *i, *n, *p, *t, *w;
        gboolean c, r, o;
        gtk_tree_model_get(tm, &iter, 0, &i, 1, &n, 2, &p, 3, &t, 4, &c, 5, &r, 6, &o, 7, &w, -1);

        // gchar msg[1000];
        // sscanf(msg, "Are you sure you want to delete (%s)", i);
        GtkWidget *dialog;
        dialog = gtk_message_dialog_new(GTK_WINDOW(window2_cnx),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        GTK_MESSAGE_WARNING,
                                        GTK_BUTTONS_YES_NO,
                                        "Are you sure you want to delete");
        gtk_window_set_title(GTK_WINDOW(dialog), "Supprimer");
        int answer = gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        if (answer == GTK_RESPONSE_YES)
        {
            supprimer_fiche(i);
            gtk_tree_store_remove(GTK_TREE_STORE(tm), &iter);
        }
    }

}


void
on_button8_assid_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
    gtk_widget_hide(window3_liste);
    gtk_widget_show(window4_assid);
}


void
on_button5_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
window5_fiche_modify = FALSE;
    GtkEntry *entry6_id = (GtkEntry *)g_object_get_data(G_OBJECT(window5_fiche), "entry6_id");
    GtkEntry *entry7_nom = (GtkEntry *)g_object_get_data(G_OBJECT(window5_fiche), "entry7_nom");
    GtkEntry *entry8_prenom = (GtkEntry *)g_object_get_data(G_OBJECT(window5_fiche), "entry8_prenom");
    GtkEntry *entry9_ntel = (GtkEntry *)g_object_get_data(G_OBJECT(window5_fiche), "entry9_ntel");
    GtkWidget *checkbutton3_gt = g_object_get_data(G_OBJECT(window5_fiche), "checkbutton3_gt");
    GtkWidget *checkbutton2_gc = g_object_get_data(G_OBJECT(window5_fiche), "checkbutton2_gc");
    GtkWidget *checkbutton1_gouv = g_object_get_data(G_OBJECT(window5_fiche), "checkbutton1_gouv");
    gtk_entry_set_text(entry6_id, "");
    gtk_entry_set_text(entry7_nom, "");
    gtk_entry_set_text(entry8_prenom, "");
    gtk_entry_set_text(entry9_ntel, "");
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkbutton3_gt), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkbutton2_gc), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkbutton1_gouv), FALSE);

    gtk_widget_hide(window3_liste);
    gtk_widget_show(window5_fiche);
}


void
on_spinbutton2_m_changed               (GtkEditable     *editable,
                                        gpointer         user_data)
{
    GtkWidget *dtj = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "spinbutton1_j");
    GtkWidget *dta = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "spinbutton3_a");
    int day = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dtj));
    int month = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(editable));
    int year = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dta));
    int days = getDaysByMonth(month, year);
    gtk_spin_button_set_range(GTK_SPIN_BUTTON(dtj), 1, days);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(dtj), day);
}


void
on_spinbutton3_a_changed               (GtkEditable     *editable,
                                        gpointer         user_data)
{
    GtkWidget *dtj = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "spinbutton1_j");
    GtkWidget *dtm = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "spinbutton2_m");
    int day = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dtj));
    int month = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dtm));
    int year = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(editable));
    int days = getDaysByMonth(month, year);
    gtk_spin_button_set_range(GTK_SPIN_BUTTON(dtj), 1, days);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(dtj), day);

}


void
on_button11_val_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
    assid a;
    GtkWidget *dtj = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "spinbutton1_j");
    GtkWidget *dtm = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "spinbutton2_m");
    GtkWidget *dta = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "spinbutton3_a");
    GtkWidget *entry5_id_assid = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "entry5_id_assid");
    GtkWidget *comboboxentry1_per = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "comboboxentry1_per");
    GtkWidget *radiobutton2_p = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "radiobutton2_p");
    GtkWidget *radiobutton1_ab = (GtkWidget *)g_object_get_data(G_OBJECT(window4_assid), "radiobutton1_ab");
    a.day = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dtj));
    a.month = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dtm));
    a.year = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dta));
    gchar *id = gtk_entry_get_text(GTK_ENTRY(entry5_id_assid));
    gchar *per = gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1_per));

    if (id == NULL || id[0] == 0)
    {
        dialog_msg(GTK_WINDOW(window4_assid), "Information", "Indiquer votre Identifiant");
        return;
    }
    strcpy(a.id, id);
    strcpy(a.per, per);
    a.p = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2_p));
    // gboolean ab = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1_ab));
    ajouter_assid(a);
    gtk_widget_show(window3_liste);
    gtk_widget_hide(window4_assid);
}


void
on_button10_retour_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
    gtk_widget_show(window3_liste);
    gtk_widget_hide(window4_assid);
}


void
on_button13_ret_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
    gtk_widget_show(window3_liste);
    gtk_widget_hide(window5_fiche);
}


void
on_button12_val_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *entry6_id = g_object_get_data(G_OBJECT(window5_fiche), "entry6_id");
    GtkWidget *entry7_nom = g_object_get_data(G_OBJECT(window5_fiche), "entry7_nom");
    GtkWidget *entry8_prenom = g_object_get_data(G_OBJECT(window5_fiche), "entry8_prenom");
    GtkWidget *entry9_ntel = g_object_get_data(G_OBJECT(window5_fiche), "entry9_ntel");
    GtkWidget *checkbutton3_gt = g_object_get_data(G_OBJECT(window5_fiche), "checkbutton3_gt");
    GtkWidget *checkbutton2_gc = g_object_get_data(G_OBJECT(window5_fiche), "checkbutton2_gc");
    GtkWidget *checkbutton1_gouv = g_object_get_data(G_OBJECT(window5_fiche), "checkbutton1_gouv");
    GtkWidget *fiche_pwd = g_object_get_data(G_OBJECT(window5_fiche), "entry1");

    GtkTreeView *ouv = (GtkTreeView *)g_object_get_data(G_OBJECT(window3_liste), "treeview1_ouv");
    GtkTreeSelection *tsel = gtk_tree_view_get_selection(ouv);
    GtkTreeIter iter;
    GtkTreeModel *tm;
    fiche fh;
    strcpy(fh.id, gtk_entry_get_text(GTK_ENTRY(entry6_id)));
    strcpy(fh.nom ,gtk_entry_get_text(GTK_ENTRY(entry7_nom)));
    strcpy(fh.prenom, gtk_entry_get_text(GTK_ENTRY(entry8_prenom)));
    strcpy(fh.phone, gtk_entry_get_text(GTK_ENTRY(entry9_ntel)));
    fh.client=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbutton1_gouv));
    fh.capteur=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbutton2_gc));
    fh.troupeau=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbutton3_gt));
    if (window5_fiche_modify == TRUE)
    {
        if (!gtk_tree_selection_get_selected(tsel, &tm, &iter))
        {
            return;
        }
        modifier_fiche(fh.id, fh);
    }
    else
    {
        tm = gtk_tree_view_get_model(ouv);
        gtk_tree_store_append(GTK_TREE_STORE(tm), &iter, NULL);
        ajouter_fiche(fh);
    }
    if (GTK_IS_TREE_MODEL(tm))
    {
        gtk_tree_store_set(GTK_TREE_STORE(tm), &iter,
                           0, gtk_entry_get_text(GTK_ENTRY(entry6_id)),
                           1, gtk_entry_get_text(GTK_ENTRY(entry7_nom)),
                           2, gtk_entry_get_text(GTK_ENTRY(entry8_prenom)),
                           3, gtk_entry_get_text(GTK_ENTRY(entry9_ntel)),
                           4, gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbutton1_gouv)),
                           5, gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbutton2_gc)),
                           6, gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbutton3_gt)),
                           -1);
    }

    gtk_widget_show(window3_liste);
    gtk_widget_hide(window5_fiche);
}


void
on_button_aj_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_mod_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_sup_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_rt_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_aff_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_1val_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_radiobutton1_oui_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton2_non_clicked            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_ok1_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_checkbutton1_oui_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checkbutton2_non_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ok2_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_buttonOK_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonSupprimer_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button7_deconnex_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button16_valider_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button18_ajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button19_modif_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button20_supp_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button21_recherche_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button6_deconnex_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}
void
on_dc_destroy                          (GtkObject       *object,
                                        gpointer         user_data)
{
    gtk_main_quit();
}

