
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>

typedef struct
{
    gchar id[256];
    gchar prenom[256];
    gchar nom[256];
    gchar phone[20];
    gboolean client;
    gboolean capteur;
    gboolean troupeau;
    gchar password[256];
} fiche;
typedef struct
{
    gchar id[256];
    int day;
    int month;
    int year;
    gchar per[100];
    gboolean p;
} assid;

typedef struct
{
    gchar id[256];
    gchar day[3];
    gchar month[3];
    gchar year[5];
    gboolean p;
    int maxabs;
} meilleur;


void ajouter_fiche(fiche fh);
void supprimer_fiche(gchar *char_id);
void modifier_fiche(gchar *char_id, fiche fm);
void ajouter_assid(assid a);
gchar *verify_assid(gchar *anne);


  GtkWidget *window1_acceuil;
  GtkWidget *window2_cnx;
  GtkWidget *window3_liste;
  GtkWidget *window4_assid;
  GtkWidget *window5_fiche;
  GtkWidget *Gestion_des_clients;
  GtkWidget *Ajout_Modif_client;
  GtkWidget *windowsupp1;
  GtkWidget *windowmodif2;
  GtkWidget *window1;
  GtkWidget *window2;
  GtkWidget *window_fiche_troup;
  GtkWidget *window8_troupeau;

char window5_fiche_modify;
int getDaysByMonth(int m, int y);
void listOuvrier(GtkTreeView *treeview, GtkTreeModel *model);
void dialog_msg(GtkWindow *window, gchar *title, const gchar *msg);

gboolean verify_connection(const gchar *id_text, const gchar *pwd_text);
