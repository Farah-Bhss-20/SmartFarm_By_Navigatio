#include <gtk/gtk.h>


void
on_dc_destroy                          (GtkObject       *object,
                                        gpointer         user_data);

void
on_button1_connexion_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_cal_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_seche_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_cnx_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_rech_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_ret_acc_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_assid_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_spinbutton2_m_changed               (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_spinbutton3_a_changed               (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_button11_val_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_retour_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_ret_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_val_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_sup_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rt_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_aff_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_1val_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_oui_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_non_clicked            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ok1_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_oui_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_non_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_ok2_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonOK_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonSupprimer_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_deconnex_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_valider_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18_ajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_modif_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_supp_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button21_recherche_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_deconnex_clicked            (GtkButton       *button,
                                        gpointer         user_data);
