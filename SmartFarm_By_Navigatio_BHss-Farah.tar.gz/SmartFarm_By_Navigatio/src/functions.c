#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>

#include "functions.h"


void ajouter_fiche(fiche fh)
{
  FILE *f = fopen("ouvrier.txt", "a+");
  if (f != NULL)
  {
    fprintf(f, "%s %s %s %s %d %d %d %s\n", fh.id, fh.prenom, fh.nom, fh.phone, fh.client, fh.capteur, fh.troupeau, fh.password);
    fclose(f);
  }
}
void supprimer_fiche(gchar *char_id)
{
  char *fn = "ouvrier.txt";
  FILE *fr = NULL, *fw = NULL;
  fw = fopen("~ouvrier.txt", "w+");
  fr = fopen(fn, "r+");
  fiche fh;
  if (fr && fw)
  {
    while (fscanf(fr, "%s %s %s %s %d %d %d %s\n", fh.id, fh.prenom, fh.nom, fh.phone, &fh.client, &fh.capteur, &fh.troupeau, fh.password) != EOF)
    {
      if (strcmp(fh.id, char_id) != 0)
      {
        fprintf(fw, "%s %s %s %s %d %d %d %s\n", fh.id, fh.prenom, fh.nom, fh.phone, fh.client, fh.capteur, fh.troupeau, fh.password);
      }
    }
    fclose(fr);
    fclose(fw);
    remove(fn);
    rename("~ouvrier.txt", fn);
  }
}
void modifier_fiche(gchar *char_id, fiche fm)
{
  char *fn = "ouvrier.txt";
  FILE *fr = NULL, *fw = NULL;
  fw = fopen("~ouvrier.txt", "w+");
  fr = fopen(fn, "r+");
  fiche fh;
  if (fr && fw)
  {
    while (fscanf(fr, "%s %s %s %s %d %d %d %s\n", fh.id, fh.prenom, fh.nom, fh.phone, &fh.client, &fh.capteur, &fh.troupeau, fh.password) != EOF)
    {
      if (strcmp(fh.id, char_id) != 0)
      {
        fprintf(fw, "%s %s %s %s %d %d %d %s\n", fh.id, fh.prenom, fh.nom, fh.phone, fh.client, fh.capteur, fh.troupeau, fh.password);
      }
      else
      {
        fprintf(fw, "%s %s %s %s %d %d %d %s\n", fm.id, fm.prenom, fm.nom, fm.phone, fm.client, fm.capteur, fm.troupeau, fm.password);
      }
    }
    fclose(fr);
    fclose(fw);
    remove(fn);
    rename("~ouvrier.txt", fn);
  }
}
void ajouter_assid(assid a)
{
  FILE *f = fopen("assid.txt", "a+");
  if (f != NULL)
  {
    fprintf(f, "%s %d %d %d %s %d\n", a.id, a.day, a.month, a.year, a.per, a.p);
    fclose(f);
  }
}


int in_assid(meilleur *a, gchar *id, int l)
{
  int i = 0;
  for (i = 0; i < l; i++)
  {
    if (strcmp(a[i].id, id)==0)
    {
      return i;
    }
  }
  return -1;
}
gchar *verify_ab_assid(meilleur *a, int l)
{
  gchar *r = (gchar *)malloc(1000);
  memset(r, 0, 1000);
  if (l > 0)
  {
    int v = a[0].maxabs;
    int i = 1;
        strcpy(r, a[0].id);
    for (i = 1; i < l; i++)
    {
      if (a[i].maxabs < v)
      {
        v = a[i].maxabs;
        strcpy(r, a[i].id);
      }
    }
  }
		printf("%d\n",(r[1]));
  return r;
}

gchar *verify_assid(gchar *anne)
{

  FILE *f = fopen("absenteisme.txt", "a+");
  meilleur a, aa[6000];
  int i = 0;
  if (f != NULL)
  {
    while (fscanf(f, "%s %s %s %s %d\n", a.id, a.day, a.month, a.year, &a.p) != EOF)
    {
      if (strcmp(a.year, anne))
      {
        int j = in_assid(aa, a.id, i);
        if (j == -1)
        {

          strcpy(aa[i].id, a.id);
          //aa = (meilleur *)malloc(sizeof(meilleur));
          aa[i].maxabs = a.p == FALSE ? 1 : 0;
          i++;
        }
        else
        {
          //aa = (meilleur *)realloc(aa,sizeof(meilleur)*(i+1));
          aa[j].maxabs += a.p == FALSE ? 1 : 0;
        }
      }
    }
    fclose(f);
  }
gchar *r = verify_ab_assid(aa, i);

  return r;
}













int getDaysByMonth(int m, int y)
{
  switch (m)
  {
  case 1:
  case 3:
  case 5:
  case 7:
  case 8:
  case 10:
  case 12:
    return 31;
  case 2:
    return y % 4 == 0 ? 29 : 28;
  default:
    return 30;
    break;
  }
}

void listOuvrier(GtkTreeView *treeview, GtkTreeModel *model)
{
  FILE *f = fopen("ouvrier.txt", "r");
  if (f != NULL)
  {
    gchar id_f[256], fn_f[256], ln_f[256], pn_f[256], pw_f[256];
    memset(id_f, 0, 256);
    memset(fn_f, 0, 256);
    memset(ln_f, 0, 256);
    memset(pn_f, 0, 256);
    memset(pw_f, 0, 256);
    gboolean cl_f, cp_f, tr_f;
    while (fscanf(f, "%s %s %s %s %d %d %d %s\n", id_f, fn_f, ln_f, pn_f, &cl_f, &cp_f, &tr_f, pw_f) != EOF)
    {
      GtkTreeIter toplevel;
      gtk_tree_store_append(GTK_TREE_STORE(model), &toplevel, NULL);
      gtk_tree_store_set(GTK_TREE_STORE(model), &toplevel,
                         0, id_f,
                         1, fn_f,
                         2, ln_f,
                         3, pn_f,
                         4, cl_f,
                         5, cp_f,
                         6, tr_f,
                         -1);
    }
  }
}
void dialog_msg(GtkWindow *window, gchar *title, const gchar *msg)
{
  GtkWidget *dialog;
  dialog = gtk_message_dialog_new(window,
                                  GTK_DIALOG_DESTROY_WITH_PARENT,
                                  GTK_MESSAGE_WARNING,
                                  GTK_BUTTONS_OK,
                                  msg);
  gtk_window_set_title(GTK_WINDOW(dialog), title);
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
}
gboolean verify_connection(const gchar *id_text, const gchar *pwd_text)
{
  gchar id_f[256], fn_f[256], ln_f[256], pn_f[256], pw_f[256];
  gboolean is_login = FALSE;
  FILE *f = fopen("ouvrier.txt", "r");
  if (f != NULL)
  {
    memset(id_f, 0, 256);
    memset(fn_f, 0, 256);
    memset(ln_f, 0, 256);
    memset(pn_f, 0, 256);
    memset(pw_f, 0, 256);
    gboolean cl_f, cp_f, tr_f;
    while (fscanf(f, "%s %s %s %s %d %d %d %s\n", id_f, fn_f, ln_f, pn_f, &cl_f, &cp_f, &tr_f, pw_f) != EOF)
    {
      if (strcmp(id_f, id_text) == 0 && strcmp(pw_f, pwd_text) == 0)
      {
        is_login = TRUE;
        break;
      }
    }

    fclose(f);
  }
  return is_login;
}
