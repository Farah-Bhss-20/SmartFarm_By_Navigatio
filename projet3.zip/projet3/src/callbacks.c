#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "client.h"
#include <string.h>
#include "date.h"

char text22[20];
client t;
void
on_treeview_client_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;

gchar* nom;
gchar* prenom;
gchar* id;
gchar* numero;
gchar* adresse;
gchar* sexe;


GtkTreeModel *model= gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model, &iter , path)){
gtk_tree_model_get (GTK_LIST_STORE(model) , &iter ,0 , &nom, 1, &prenom ,2,&id , 3 , &numero, 4, &adresse,5, &sexe,-1);
strcpy(t.id,id);
strcpy(t.nom,nom);
strcpy(t.prenom,prenom);
strcpy(t.numero,numero);
strcpy(t.adresse,adresse);
strcpy(t.sexe,sexe);
strcpy(text22,id);
//supprimer_client(c.id,"client.txt");

 //afficher_client(treeview);}
}
}


void
on_button_rech_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE *f1=NULL;
GtkWidget *treeview_client;
GtkWidget *Gestion_des_clients;
GtkWidget *input;
client c;
char text44[20];

Gestion_des_clients=lookup_widget(objet,"Gestion_des_clients");

input=lookup_widget(objet,"entry6");
strcpy(text44,gtk_entry_get_text(GTK_ENTRY(input)));
c=recherche(text44);
f1=fopen("recherche.txt","w");
if(f1!=NULL)
{
fprintf(f1,"%s %s %s %s %s %s\n",c.nom,c.prenom,c.id,c.numero,c.adresse,c.sexe);
}
fclose(f1);
treeview_client=lookup_widget(Gestion_des_clients,"treeview_client");
afficher_client(treeview_client,"recherche.txt");
}

void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Ajout_Modif_client;
GtkWidget *Gestion_des_clients;
GtkWidget *treeview_client;

Gestion_des_clients=lookup_widget(objet,"Gestion_des_clients");

gtk_widget_destroy(Gestion_des_clients);

Ajout_Modif_client=lookup_widget(objet,"Ajout_Modif_client");
Ajout_Modif_client=create_Ajout_Modif_client();
gtk_widget_show(Ajout_Modif_client);

}


void
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowmodif2;
GtkWidget *Gestion_des_clients;
GtkWidget *treeview_client;
GtkWidget *input;
//client c;

Gestion_des_clients=lookup_widget(objet,"Gestion_des_clients");

/*input=lookup_widget(objet,"entry6");
strcpy(text112,gtk_entry_get_text(GTK_ENTRY(input))); */

gtk_widget_destroy(Gestion_des_clients);

windowmodif2=lookup_widget(objet,"windowmodif2");
windowmodif2=create_windowmodif2();
gtk_widget_show(windowmodif2);

}

char text111[100];
void
on_button_sup_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowsupp1;
GtkWidget *Gestion_des_clients;
GtkWidget *treeview_client;
GtkWidget *input;
/*client c;

Gestion_des_clients=lookup_widget(objet,"Gestion_des_clients");

input=lookup_widget(objet,"entry6");
strcpy(text111,gtk_entry_get_text(GTK_ENTRY(input)));

gtk_widget_destroy(Gestion_des_clients);

windowsupp1=lookup_widget(objet,"windowsupp1");
windowsupp1=create_windowsupp1();
gtk_widget_show(windowsupp1); */

Gestion_des_clients=lookup_widget(objet,"Gestion_des_clients");
gtk_widget_destroy(Gestion_des_clients);

windowsupp1=lookup_widget(objet,"windowsupp1");
windowsupp1=create_windowsupp1();
gtk_widget_show(windowsupp1);


}


void
on_button_rt_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button1_ret_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_aff_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Ajout_Modif_client;
GtkWidget *Gestion_des_clients;
GtkWidget *treeview_client;

Ajout_Modif_client=lookup_widget(objet,"Ajout_Modif_client");
gtk_widget_destroy(Ajout_Modif_client);

Gestion_des_clients=lookup_widget(objet,"Gestion_des_clients");
Gestion_des_clients=create_Gestion_des_clients();
gtk_widget_show(Gestion_des_clients);

treeview_client=lookup_widget(Gestion_des_clients,"treeview_client");
afficher_client(treeview_client,"client.txt");

}


void
on_button_modfin_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_1val_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
client c;
int test;
GtkWidget *input1, *input2, *input3, *input4, *input5, *input6;
GtkWidget *Ajout_Modif_client;
Ajout_Modif_client=lookup_widget(objet,"Ajout_Modif_client");

input1=lookup_widget(objet,"entry_n1");
input2=lookup_widget(objet,"entry_pn1");
input3=lookup_widget(objet,"entry_cn1");
input4=lookup_widget(objet,"entry_tel");
input5=lookup_widget(objet,"entry_ad1");

input6=lookup_widget(objet,"combobox_se");


strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.numero,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(c.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));
Ajout_client(c,"client.txt");
}


void
on_button2_ret_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_cal_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget* output;
char res[20];
GtkWidget* taux;
int pp;
pp=nombre_ouvrier("jj.txt");

sprintf(res,"%d",pp);

//strcpy(res,"bbaab");
taux=lookup_widget(objet,"taux");
output=lookup_widget(objet,"label_restaux");
gtk_label_set_text (GTK_LABEL(output),res);

}

int x;
void
on_radiobutton1_oui_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
x=1;
}


void
on_radiobutton2_non_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
x=2;
}


void
on_ok1_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *treeview_client;
GtkWidget *Gestion_des_clients;
GtkWidget *windowsupp1;
//client c;
/*Gestion_des_clients=lookup_widget(objet,"Gestion_des_clients");
input=lookup_widget(objet,"entry6");
strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input)));   */

//c=recherche(text111);
if(x==1)
{supprimer_client(text22,"client.txt");}
if((x==1)||(x==2))
 {windowsupp1=lookup_widget(objet,"windowsupp1");
gtk_widget_destroy(windowsupp1);

Gestion_des_clients=lookup_widget(objet,"Gestion_des_clients");
Gestion_des_clients=create_Gestion_des_clients();
gtk_widget_show(Gestion_des_clients);

treeview_client=lookup_widget(Gestion_des_clients,"treeview_client");
afficher_client(treeview_client,"client.txt");
}
}

int choix1[]={0,0};
void
on_checkbutton2_non_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active (togglebutton))
{choix1[1]=1;}

}


void
on_checkbutton1_oui_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active (togglebutton))
{choix1[0]=1;}

}


void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gestion_des_clients;
GtkWidget *windowmodif2;
GtkWidget *Ajout_Modif_client;
GtkWidget *treeview_client;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
char ff[20];
GtkWidget* output;
 
if(choix1[0]==1)
{

char ff[20];
strcpy(ff,t.id);
output=lookup_widget(objet_graphique,"label_n2");
gtk_label_set_text (GTK_LABEL(output),"oo");
supprimer_client(t.id,"client.txt");
windowmodif2=lookup_widget(objet_graphique,"windowmodif2");
gtk_widget_destroy(windowmodif2);
Ajout_Modif_client=lookup_widget(objet_graphique,"Ajout_Modif_client");



Ajout_Modif_client=create_Ajout_Modif_client();
gtk_widget_show(Ajout_Modif_client); 



/*strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input1),''');
strcpy(c.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));


input2=lookup_widget(objet,"entry_pn1");
input3=lookup_widget(objet,"entry_cn1");
input4=lookup_widget(objet,"entry_tel");
input5=lookup_widget(objet,"entry_ad1");

input6=lookup_widget(objet,"combobox_se");





input2=lookup_widget(objet_graphique,"");
input3=lookup_widget(objet_graphique,"label_cn2");
input4=lookup_widget(objet_graphique,"label_tel2");
input5=lookup_widget(objet_graphique,"elabel_ad2");

input6=lookup_widget(objet_graphique,"label_se2");


gtk_label_set_text(GTK_LABEL(input1),t.nom);

gtk_label_set_text(GTK_LABEL(input2),t.prenom);
gtk_label_set_text(GTK_LABEL(input3),t.id);
gtk_label_set_text(GTK_LABEL(input4),t.numero);
gtk_label_set_text(GTK_LABEL(input5),t.adresse);
gtk_label_set_text(GTK_LABEL(input6),t.sexe);
Ajout_Modif_client=create_Ajout_Modif_client();
windowmodif2=lookup_widget(objet_graphique,"windowmodif2");

gtk_widget_destroy(windowmodif2);

Ajout_Modif_client=lookup_widget(objet_graphique,"Ajout_Modif_client");
Ajout_Modif_client=create_Ajout_Modif_client();
gtk_widget_show(Ajout_Modif_client);
 modiffier_client(t,"client.txt");  */
} 

if(choix1[1]==1)
 {windowmodif2=lookup_widget(objet_graphique,"windowmodif2");
gtk_widget_destroy(windowmodif2);

Gestion_des_clients=lookup_widget(objet_graphique,"Gestion_des_clients");
Gestion_des_clients=create_Gestion_des_clients();
gtk_widget_show(Gestion_des_clients);

treeview_client=lookup_widget(Gestion_des_clients,"treeview_client");
afficher_client(treeview_client,"client.txt");}


}

