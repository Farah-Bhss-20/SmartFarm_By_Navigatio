#include "client.h"
#include <stdio.h>
#include <string.h>
#include<gtk/gtk.h>

enum
{
NOM,
PRENOM,
CIN,
NUMERO,
ADRESSE,
SEXE,
COLUMNS ,
};




void Ajout_client(client c,char fichier[])
{
char num[10];
FILE *f=NULL;
f=fopen(fichier,"a");
if(f!=NULL)

{fprintf(f,"%s %s %s %s %s %s\n",c.nom,c.prenom,c.id,c.numero,c.adresse,c.sexe);

}
fclose(f);
}



void supprimer_client(char cin[],char fichier[])
{

FILE *f1=NULL;
FILE *f2=NULL;
char nom[10];
char prenom[10];
char adresse[10];
char id[10];
char numero[10];
char sexe[100];
int t=-1;
f1=fopen(fichier,"r");
f2=fopen("suprimer.txt","w");
if(f2==NULL || f1==NULL)
{
return;
}
else
{while(fscanf(f1,"%s %s %s %s %s %s\n",nom,prenom,id,numero,adresse,sexe)!=EOF)

{
if(strcmp(cin,id)!=0)
  fprintf(f2,"%s %s %s %s %s %s\n",nom,prenom,id,numero,adresse,sexe);
 
}

fclose(f1);
fclose(f2);
remove(fichier);
rename("suprimer.txt",fichier);

}
}



void afficher_client(GtkWidget *liste,char fichier[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char nom[20];
char prenom[20];
char cin[10];
char numero[10];
char adresse[20];
char sexe[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{




renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" numero",renderer,"text",NUMERO,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" adresse",renderer,"text",ADRESSE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 
}
store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);    



f=fopen(fichier,"r");
if(f==NULL)
{
return;
}
else
{f=fopen(fichier,"a+");
while(fscanf(f,"%s %s %s %s %s %s \n",nom,prenom,cin,numero,adresse,sexe)!=EOF)

{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter, NOM, nom, PRENOM, prenom, CIN, cin, NUMERO, numero, ADRESSE, adresse, SEXE, sexe , -1); 

}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

client recherche(char x[])
{
int test=0;
client c;
FILE *f;



char ch1[20];
char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];
char ch6[20];
f=fopen("client.txt","a+");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s",ch1,ch2,ch3,ch4,ch5,ch6)!=EOF)
{if(strcmp(x,ch3)==0)
{
strcpy(c.nom,ch1);
strcpy(c.prenom,ch2);
strcpy(c.id,ch3);
strcpy(c.numero,ch4);
strcpy(c.adresse,ch5);
strcpy(c.sexe,ch6);
}
}
fclose(f);
}
return (c);

}


void modiffier_client(client c,char fichier[])
{

FILE *f1=NULL;
FILE *f2=NULL;

char nom[10];
char prenom[10];
char adresse[10];
char id[10];
char numero[10];
char sexe[20];
int t=-1;

f1=fopen("client.txt","r");
if(f1!=NULL)
{
f2=fopen("modifier.txt","a");

while(fscanf(f1,"%s %s %s %s %s %s\n",nom,prenom,id,numero,adresse,sexe)!=EOF)
{
if(strcmp(c.id,id)!=0)
  fprintf(f2,"%s %s %s %s %s %s\n",nom,prenom,id,numero,adresse,sexe);
else
   {
      fprintf(f2,"%s %s %s %s %s %s\n",c.nom,c.prenom,c.id,c.numero,c.adresse,c.sexe);
  
    }
    }
fclose(f1);
fclose(f2);
 
 }

remove("client.txt");
rename("modifier.txt","client.txt");

}             






