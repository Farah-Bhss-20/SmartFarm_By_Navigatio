#include <gtk/gtk.h>
/*typedef struct date
{
int jour;
int mois;
int annee;
}date;*/

typedef struct client
{
char nom[20];
char prenom[20];
char id[10];
char numero[20];
char adresse[20];
char sexe[100];
//date date_n;

}client;

void Ajout_client(client c,char fichier[]);
void supprimer_client(char cin[],char fichier[]);
void modiffier_client(client c,char fichier[]);
client recherche(char x[]);
void afficher_client(GtkWidget *liste,char fichier[]);
