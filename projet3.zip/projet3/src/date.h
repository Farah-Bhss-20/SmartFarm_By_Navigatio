#include <stdlib.h>
typedef struct
{
int jour;
int annee;
int mois;
}Date;
float calculer_taux (int annee, char fichier[], float taux[], int n);
int nombre_ouvrier(char fichier[]);
