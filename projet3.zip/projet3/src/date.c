
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "date.h"
#include <stddef.h>

int nombre_ouvrier(char fichier[])
{
int id;
int jour;
int mois;
int anne;
int abs;
FILE *f=NULL;
int i,n,p,k,j;
int t[20000];
char ch[20];
n=0;
f=fopen("absenteisme.txt","r");
if(f!=NULL)

//{ while(fscanf(f,"%d %d %d %d %d\n",&id,&jour,&mois,&anne,&abs)!=EOF)
//{  {n=n+1;}}
{while(fscanf(f,"%d %d %d %d %d\n",&id,&jour,&mois,&anne,&abs)!=EOF)
{
for(i=0;i<16200;i++)
  t[i]=id;
}fclose(f);
}
p=1;
for(i=1;i<n;i++)
{
k=0;
j=0;
for(j=0;j<i;j++)
{
 if(t[i]==t[j])
  {
   k=i;
   j=i+1;
  }
 if(k==0)
  p++;
}
//sprintf(ch,"%d",n);
}
return (p);
}








float calculer_taux (int annee, char fichier[], float taux[], int n)
{
int id;
int jour;
int mois;
int anne;
int abs;
FILE *f=NULL;
int i;

//float taux;
f=fopen(fichier,"r");
for(i=0;i<12; i++)
taux[i]=0;
if(f!=NULL)

{ while(fscanf(f,"%d %d %d %d %d\n",&id,&jour,&mois,&anne,&abs)!=EOF)
{
if(anne==annee && abs==1)
taux[mois-1]++;

}fclose(f);
}
for(i=0;i<12; i++)
taux[i]=taux[i]/n;



}
