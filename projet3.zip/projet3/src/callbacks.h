#include <gtk/gtk.h>


void
on_treeview_client_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_rech_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sup_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rt_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_ret_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_aff_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modfin_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_1val_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_ret_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_cal_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton1_oui_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_non_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ok1_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton2_non_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_oui_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
